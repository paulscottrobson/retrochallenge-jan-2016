#
#	VTL To Binary
#
import re

def compile(srcFile,objFile):
	s = [x.strip() for x in open(srcFile,"r").readlines() if x.strip() != ""]
	obj = []
	for l in s:
		m = re.match("^([0-9]+)\s+(.*)$",l)
		assert m is not None
		print(m.groups())
		obj.append(len(m.group(2))+4)
		line = int(m.group(1))
		obj.append(line % 256)
		obj.append(line / 256)
		for s in m.group(2):
			obj.append(ord(s))
		obj.append(0)

	obj.append(0)
	h = open(objFile,"w")
	for s in obj:
		h.write("    db  {0}\n".format(s))

	print(len(obj))

compile("factorial.vtl","factorial.dat")
compile("hurkle.vtl","hurkle.dat")